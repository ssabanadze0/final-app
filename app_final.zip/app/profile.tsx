// app/profile.tsx
import { useAuth } from "@/store/authContext";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useState } from "react";
import { Controller, useForm } from "react-hook-form";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import * as yup from "yup";

type LoginForm = {
  username: string;
  password: string;
};

type RegisterForm = {
  username: string;
  email: string;
  password: string;
};

const loginSchema = yup.object({
  username: yup.string().required("Username is required"),
  password: yup.string().required("Password is required"),
});

const registerSchema = yup.object({
  username: yup.string().required("Username is required"),
  email: yup.string().email("Invalid email").required("Email is required"),
  password: yup
    .string()
    .min(4, "Password must be at least 4 characters")
    .required("Password is required"),
});

export default function Profile() {
  const { user, login, register, logout, loading, error } = useAuth();

  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [registerSuccess, setRegisterSuccess] = useState(false);

  // ----- LOGIN FORM -----
  const {
    control: loginControl,
    handleSubmit: handleLoginSubmit,
    formState: { errors: loginErrors },
  } = useForm<LoginForm>({
    resolver: yupResolver(loginSchema),
    defaultValues: {
      username: "johnd", // dev helper
      password: "m38rmF$",
    },
  });

  async function onLogin(values: LoginForm) {
    await login(values.username, values.password, rememberMe);
  }

  // ----- REGISTER FORM (inside modal) -----
  const {
    control: regControl,
    handleSubmit: handleRegSubmit,
    formState: { errors: regErrors },
  } = useForm<RegisterForm>({
    resolver: yupResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
    },
  });

  async function onRegister(values: RegisterForm) {
    const ok = await register({
      username: values.username,
      email: values.email,
      password: values.password,
    });

    if (ok) {
      setShowRegisterModal(false);
      setRegisterSuccess(true);
    }
  }

  // ---------- LOGGED IN: show profile ----------
  if (user) {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Profile</Text>

        <Text style={styles.label}>Username</Text>
        <Text style={styles.value}>{user.username}</Text>

        <Text style={styles.label}>Name</Text>
        <Text style={styles.value}>
          {user.name.firstname} {user.name.lastname}
        </Text>

        <Text style={styles.label}>Email</Text>
        <Text style={styles.value}>{user.email}</Text>

        <Text style={styles.label}>Phone</Text>
        <Text style={styles.value}>{user.phone}</Text>

        <Text style={styles.label}>Address</Text>
        <Text style={styles.value}>
          {user.address.street} {user.address.number}, {user.address.city}{" "}
          {user.address.zipcode}
        </Text>

        <Pressable style={styles.logoutBtn} onPress={logout}>
          <Text style={styles.logoutText}>Log out</Text>
        </Pressable>
      </ScrollView>
    );
  }

  // ---------- NOT LOGGED IN: login + "create account" button ----------
  return (
    <>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Login to your account</Text>

        {registerSuccess && (
          <Text style={styles.successText}>
            Account created. You can log in now.
          </Text>
        )}

        {/* Username */}
        <View style={styles.field}>
          <Text style={styles.label}>Username</Text>
          <Controller
            control={loginControl}
            name="username"
            render={({ field: { value, onChange, onBlur } }) => (
              <TextInput
                value={value}
                onChangeText={onChange}
                onBlur={onBlur}
                placeholder="johnd"
                placeholderTextColor="#999"
                autoCapitalize="none"
                editable={!loading}
                style={styles.input}
              />
            )}
          />
          {loginErrors.username && (
            <Text style={styles.errorText}>{loginErrors.username.message}</Text>
          )}
        </View>

        {/* Password + show/hide */}
        <View style={styles.field}>
          <Text style={styles.label}>Password</Text>
          <Controller
            control={loginControl}
            name="password"
            render={({ field: { value, onChange, onBlur } }) => (
              <View style={styles.passwordRow}>
                <TextInput
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  placeholder="••••••••"
                  placeholderTextColor="#999"
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                  editable={!loading}
                  style={[styles.input, styles.passwordInput]}
                />
                <Pressable
                  onPress={() => setShowPassword((prev) => !prev)}
                  style={styles.eyeBtn}
                >
                  <Text style={styles.eyeText}>
                    {showPassword ? "Hide" : "Show"}
                  </Text>
                </Pressable>
              </View>
            )}
          />
          {loginErrors.password && (
            <Text style={styles.errorText}>{loginErrors.password.message}</Text>
          )}
        </View>

        {/* Remember me */}
        <Pressable
          style={styles.rememberRow}
          onPress={() => setRememberMe((prev) => !prev)}
        >
          <View style={[styles.checkbox, rememberMe && styles.checkboxChecked]}>
            {rememberMe && <Text style={styles.checkboxTick}>✓</Text>}
          </View>
          <Text style={styles.rememberText}>Remember me</Text>
        </Pressable>

        {error && <Text style={styles.errorText}>{error}</Text>}

        <Pressable
          style={[styles.submitBtn, loading && styles.submitBtnDisabled]}
          onPress={handleLoginSubmit(onLogin)}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.submitText}>Log in</Text>
          )}
        </Pressable>

        {/* Create account button */}
        <View style={styles.registerHintRow}>
          <Text style={styles.smallText}>Don&apos;t have an account?</Text>
          <Pressable
            onPress={() => setShowRegisterModal(true)}
            style={styles.linkBtn}
          >
            <Text style={styles.linkText}>Create one</Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* ---------- REGISTRATION MODAL ---------- */}
      <Modal
        visible={showRegisterModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowRegisterModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Create a new account</Text>

            {/* Username */}
            <View style={styles.field}>
              <Text style={styles.label}>Username</Text>
              <Controller
                control={regControl}
                name="username"
                render={({ field: { value, onChange, onBlur } }) => (
                  <TextInput
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    placeholder="new_user"
                    placeholderTextColor="#999"
                    autoCapitalize="none"
                    editable={!loading}
                    style={styles.input}
                  />
                )}
              />
              {regErrors.username && (
                <Text style={styles.errorText}>
                  {regErrors.username.message}
                </Text>
              )}
            </View>

            {/* Email */}
            <View style={styles.field}>
              <Text style={styles.label}>Email</Text>
              <Controller
                control={regControl}
                name="email"
                render={({ field: { value, onChange, onBlur } }) => (
                  <TextInput
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    placeholder="you@example.com"
                    placeholderTextColor="#999"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    editable={!loading}
                    style={styles.input}
                  />
                )}
              />
              {regErrors.email && (
                <Text style={styles.errorText}>{regErrors.email.message}</Text>
              )}
            </View>

            {/* Password */}
            <View style={styles.field}>
              <Text style={styles.label}>Password</Text>
              <Controller
                control={regControl}
                name="password"
                render={({ field: { value, onChange, onBlur } }) => (
                  <TextInput
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    placeholder="Choose a password"
                    placeholderTextColor="#999"
                    secureTextEntry
                    autoCapitalize="none"
                    editable={!loading}
                    style={styles.input}
                  />
                )}
              />
              {regErrors.password && (
                <Text style={styles.errorText}>
                  {regErrors.password.message}
                </Text>
              )}
            </View>

            {error && <Text style={styles.errorText}>{error}</Text>}

            <View style={styles.modalButtonsRow}>
              <Pressable
                style={[styles.submitBtn, styles.modalPrimaryBtn]}
                onPress={handleRegSubmit(onRegister)}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.submitText}>Register</Text>
                )}
              </Pressable>

              <Pressable
                style={[styles.submitBtn, styles.modalCancelBtn]}
                onPress={() => setShowRegisterModal(false)}
                disabled={loading}
              >
                <Text style={[styles.submitText, styles.modalCancelText]}>
                  Cancel
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingTop: 40,
    backgroundColor: "#fff",
    flexGrow: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 20,
  },
  successText: {
    color: "#0a7a0a",
    fontSize: 13,
    marginBottom: 12,
  },
  field: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 16,
    backgroundColor: "#fafafa",
    color: "#000",
  },
  passwordRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  passwordInput: {
    flex: 1,
  },
  eyeBtn: {
    marginLeft: 8,
    paddingHorizontal: 8,
    paddingVertical: 6,
  },
  eyeText: {
    fontSize: 12,
    color: "#555",
  },
  rememberRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    marginTop: 4,
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "#aaa",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
    backgroundColor: "#fff",
  },
  checkboxChecked: {
    backgroundColor: "#000",
    borderColor: "#000",
  },
  checkboxTick: {
    color: "#fff",
    fontSize: 12,
    lineHeight: 12,
  },
  rememberText: {
    fontSize: 13,
    color: "#444",
  },
  errorText: {
    color: "#d00",
    fontSize: 12,
    marginTop: 4,
  },
  submitBtn: {
    marginTop: 8,
    backgroundColor: "#000",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
  },
  submitBtnDisabled: {
    opacity: 0.7,
  },
  submitText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  value: {
    fontSize: 14,
    marginBottom: 8,
  },
  logoutBtn: {
    marginTop: 24,
    backgroundColor: "#eee",
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: "center",
  },
  logoutText: {
    color: "#000",
    fontWeight: "600",
  },
  registerHintRow: {
    marginTop: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  smallText: {
    fontSize: 13,
    color: "#555",
  },
  linkBtn: {
    paddingHorizontal: 4,
    paddingVertical: 2,
  },
  linkText: {
    fontSize: 13,
    color: "#000",
    fontWeight: "600",
    textDecorationLine: "underline",
  },
  // modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  modalCard: {
    width: "100%",
    maxWidth: 420,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 12,
  },
  modalButtonsRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 8,
  },
  modalPrimaryBtn: {
    flex: 1,
  },
  modalCancelBtn: {
    flex: 1,
    backgroundColor: "#eee",
  },
  modalCancelText: {
    color: "#000",
  },
});
